#!/usr/bin/env bash
set -euo pipefail

# client_validate — Valide qu'un client a un slug valide et un nom non vide
# Args:
#   $1: slug (identifiant court requis)
#   $2: name (nom du client, non vide)
# Returns:
#   0 si valide ; 1 sinon
# Side effects: none
# Example:
#   client_validate "mon-slug" "Mon Client"
client_validate() {
  local slug="$1" name="$2"
  require_slug "$slug" || return 1
  [[ -n "$name" ]] || return 1
}
