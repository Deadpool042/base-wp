#!/usr/bin/env bash
set -euo pipefail
# client_new — Crée la structure JSON d'un client complet
# Args:
#   $1: id (UUID unique du client)
#   $2: slug (identifiant court, kebab-case)
#   $3: name (nom lisible du client)
#.  
#   $4: ts (timestamp ISO-8601 UTC)
# Returns:
#   0 toujours
# Side effects:
#   - Affiche le JSON sur stdout
# Example:
#   json="$(client_new "550e8400-e29b-41d4-a716-446655440000" "acme" "ACME Corp" "2025-01-05T14:00:00Z")</client_new"
client_new() {
  local id="$1" slug="$2" name="$3" lastname="$4" firstname="$5" ts="$6"
  jq -n \
    --arg id "$id" \
    --arg slug "$slug" \
    --arg name "$name" \
    --arg last_name "$lastname"\
    --arg first_name "$firstname" \
    --arg ts "$ts" \
    '{
      id: $id,
      slug: $slug,
      name: $name,
      lastName: $last_name,
      firstName: $first_name,
      createdAt: $ts,
      updatedAt: $ts
    }'
}
