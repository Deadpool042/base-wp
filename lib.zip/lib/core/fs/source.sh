#!/usr/bin/env bash
set -euo pipefail

# sf_source — Source un fichier relatif à $SF_ROOT
# Args:
#   $1: chemin relatif (ex: "core/log/emit.sh")
# Returns:
#   0 si OK ; 1 sinon
# Side effects:
#   charge le fichier dans le shell courant
sf_source() {
  local rel="${1:-}"
  [[ -n "$rel" ]] || { echo "[sf] sf_source: path missing" >&2; return 1; }

  [[ -n "${SF_ROOT:-}" ]] || { echo "[sf] sf_source: SF_ROOT not set" >&2; return 1; }

  local abs="$SF_ROOT/$rel"
  if [[ ! -f "$abs" ]]; then
    echo "[sf] source not found: $abs" >&2
    return 1
  fi

  # shellcheck source=/dev/null
  source "$abs"
}

# sf_require_source — Comme sf_source mais exit si KO (utile dans bootstrap)
# Args:
#   $1: chemin relatif
# Returns:
#   ne retourne pas si KO (exit 1)
sf_require_source() {
  sf_source "${1:-}" || exit 1
}