#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SF_ROOT="$(cd "$HERE/.." && pwd)"
export SF_ROOT

DATA_DIR="$SF_ROOT/data"
INDEX_DIR="$SF_ROOT/indexes"
TMP_DIR="${TMP_DIR:-$SF_ROOT/.tmp}"

mkdir -p "$DATA_DIR" "$INDEX_DIR" "$TMP_DIR"

# shellcheck source=fs/source.sh
source "$SF_ROOT/core/fs/source.sh"

sf_require_source "core/log/emit.sh"
sf_require_source "core/log/format.sh"
sf_require_source "core/fs/atomic.sh"
sf_require_source "core/fs/path.sh"
sf_require_source "core/json/jq.sh"
sf_require_source "core/strings/slug.sh"
sf_require_source "core/time/now.sh"
sf_require_source "core/validate/require.sh"
sf_require_source "core/args/parse.sh"
sf_require_source "core/select/select.sh"
sf_require_source "core/strings/uuid.sh"