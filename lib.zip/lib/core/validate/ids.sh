#!/usr/bin/env bash
set -euo pipefail

# require_uuid — Valide qu'une chaîne est un UUID syntaxiquement correct
# Args:
#   $1: UUID à valider
# Returns:
#   0 si valide ; 1 sinon
# Side effects: none
# Example:
#   require_uuid "550e8400-e29b-41d4-a716-446655440000" && echo "OK"
require_uuid() {
  [[ "$1" =~ ^[a-f0-9-]{36}$ ]] || return 1
}

# require_slug — Valide qu'une chaîne est un slug correct
# Args:
#   $1: slug à valider
# Returns:
#   0 si valide ; 1 sinon
# Side effects: none
# Example:
#   require_slug "my-project" && echo "OK"
require_slug() {
  [[ "$1" =~ ^[a-z0-9-]+$ ]] || return 1
}
