#!/usr/bin/env bash
set -euo pipefail

# require_nonempty — Valide qu'une chaîne n'est pas vide
# Args:
#   $1: chaîne à valider
# Returns:
#   0 si non vide ; 1 sinon
# Side effects: none
# Example:
#   require_nonempty "$name" || { echo "Name required"; return 1; }
require_nonempty() {
  local v="${1:-}"
  [[ -n "$v" ]] || return 1
}

# require_slug — Valide qu'une chaîne est un slug valide via slug_require()
# Args:
#   $1: slug à valider
# Returns:
#   0 si valide ; 1 sinon
# Side effects: none
# Example:
#   require_slug "my-project" && echo "Valid"
require_slug() {
  local v="${1:-}"
  slug_require "$v" || return 1
}

# require_file — Valide qu'un chemin pointe vers un fichier régulier existant
# Args:
#   $1: path du fichier
# Returns:
#   0 si fichier existe ; 1 sinon
# Side effects: none
# Example:
#   require_file "/etc/passwd" && echo "File exists"
require_file() {
  local p="${1:-}"
  [[ -f "$p" ]] || return 1
}
