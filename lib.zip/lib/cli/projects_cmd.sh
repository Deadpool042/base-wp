#!/usr/bin/env bash
set -euo pipefail

# projects_cmd — Gestion des projets
