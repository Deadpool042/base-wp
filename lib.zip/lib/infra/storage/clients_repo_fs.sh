#!/usr/bin/env bash
set -euo pipefail

# clients_repo_init — Initialise le répertoire des clients et l'index des slugs
# Args: none
# Returns:
#   0 toujours
# Side effects:
#   - Crée le répertoire retourné par clients_dir
#   - Initialise clients_index avec '{}' si absent
# Example:
#   clients_repo_init
clients_repo_init() {
  mkdir -p "$(clients_dir)"
  [[ -f "$(clients_index)" ]] || echo '{}' > "$(clients_index)"
}

# clients_repo_slug_exists — Vérifie si un slug de client existe dans l'index
# Args:
#   $1: slug du client à vérifier
# Returns:
#   0 si trouvé ; 1 sinon
# Side effects: none
# Example:
#   clients_repo_slug_exists "mon-slug" && echo "Exists"
clients_repo_slug_exists() {
  jq -e --arg slug "$1" '.[$slug]' "$(clients_index)" >/dev/null
}

# clients_repo_save — Sauvegarde le fichier client et met à jour l'index des slugs
# Args:
#   $1: id du client (UUID)
#   $2: slug du client
#   $3: contenu JSON à écrire dans le fichier client
# Returns:
#   0 si succès
# Side effects:
#   - Écrit le fichier client
#   - Met à jour atomiquement clients_index
# Example:
#   clients_repo_save "550e8400..." "acme" '{"name":"ACME"}'
clients_repo_save() {
  local id="$1" slug="$2" json="$3"
  echo "$json" > "$(client_file "$id")"
  jq --arg slug "$slug" --arg id "$id" '. + {($slug):$id}' \
    "$(clients_index)" > "$(clients_index).tmp"
  mv "$(clients_index).tmp" "$(clients_index)"
}
