#!/usr/bin/env bash
set -euo pipefail

# clients_dir — Retourne le chemin absolu du répertoire des clients
# Args: none
# Returns:
#   0 toujours
# Side effects:
#   - Affiche le chemin sur stdout
# Example:
#   dir="$(clients_dir)"
clients_dir() { echo "$DATA_DIR/clients"; }

# client_file — Retourne le chemin absolu du fichier JSON d'un client
# Args:
#   $1: id du client (UUID)
# Returns:
#   0 toujours
# Side effects:
#   - Affiche le chemin sur stdout
# Example:
#   path="$(client_file "550e8400-e29b-41d4-a716-446655440000")"
client_file() { echo "$(clients_dir)/$1.json"; }

# clients_index — Retourne le chemin absolu de l'index des slugs clients
# Args: none
# Returns:
#   0 toujours
# Side effects:
#   - Affiche le chemin sur stdout
# Example:
#   idx="$(clients_index)"
clients_index() { echo "$INDEX_DIR/clients_by_slug.json"; }
