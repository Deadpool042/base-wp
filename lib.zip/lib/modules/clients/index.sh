#!/usr/bin/env bash
set -euo pipefail

# domain
 sf_require_source "modules/clients/domain/model.sh"

# infra
sf_require_source "modules/clients/repo/clients_repo.sh"

# usecases
sf_require_source "modules/clients/usecases/resolve.sh"
sf_require_source "modules/clients/usecases/create.sh"
sf_require_source "modules/clients/usecases/list.sh"
sf_require_source "modules/clients/usecases/show.sh"
sf_require_source "modules/clients/usecases/update.sh"
sf_require_source "modules/clients/usecases/delete.sh"