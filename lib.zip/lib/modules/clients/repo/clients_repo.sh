#!/usr/bin/env bash
set -euo pipefail

# clients_repo_dir — Retourne le chemin du répertoire clients
# Args: none
# Returns:
#   0 toujours
# Side effects:
#   - Affiche le chemin sur stdout
# Example:
#   dir="$(clients_repo_dir)"
clients_repo_dir() { echo "$DATA_DIR/clients"; }

# clients_repo_file_by_id — Retourne le chemin du fichier client pour un ID donné
# Args:
#   $1: id (UUID du client)
# Returns:
#   0 toujours
# Side effects:
#   - Affiche le chemin sur stdout
# Example:
#   file="$(clients_repo_file_by_id "uuid-123")"
clients_repo_file_by_id() { echo "$(clients_repo_dir)/$1.json"; }

# clients_index_dir — Retourne le chemin du répertoire d'index clients
# Args: none
# Returns:
#   0 toujours
# Side effects:
#   - Affiche le chemin sur stdout
# Example:
#   idx_dir="$(clients_index_dir)"
clients_index_dir() { echo "$INDEX_DIR/clients/by-slug"; }

# clients_index_file_by_slug — Retourne le chemin du fichier d'index pour un slug
# Args:
#   $1: slug (identifiant court du client)
# Returns:
#   0 toujours
# Side effects:
#   - Affiche le chemin sur stdout
# Example:
#   idx_file="$(clients_index_file_by_slug "mon-client")"
clients_index_file_by_slug() { echo "$(clients_index_dir)/$1"; }

# clients_repo_init — Initialise les répertoires de stockage clients
# Args: none
# Returns:
#   0 toujours
# Side effects:
#   - Crée les répertoires s'ils n'existent pas
# Example:
#   clients_repo_init
clients_repo_init() {
  mkdir -p "$(clients_repo_dir)" "$(clients_index_dir)"
}

# clients_repo_exists_id — Vérifie qu'un client existe par ID
# Args:
#   $1: id (UUID du client)
# Returns:
#   0 si existe ; 1 sinon
# Side effects: none
# Example:
#   clients_repo_exists_id "uuid-123" && echo "Found"
clients_repo_exists_id() {
  local id="${1:-}"
  [[ -n "$id" ]] || return 1
  [[ -f "$(clients_repo_file_by_id "$id")" ]]
}

# clients_repo_get_by_id — Récupère le JSON d'un client par ID
# Args:
#   $1: id (UUID du client)
# Returns:
#   0 si trouvé ; 1 sinon
# Side effects:
#   - Affiche le JSON sur stdout
# Example:
#   json="$(clients_repo_get_by_id "uuid-123")"
clients_repo_get_by_id() {
  local id="${1:-}"
  [[ -n "$id" ]] || return 1
  local f
  f="$(clients_repo_file_by_id "$id")"
  [[ -f "$f" ]] || return 1
  cat "$f"
}

# clients_repo_find_id_by_slug — Trouve l'ID d'un client par son slug
# Args:
#   $1: slug (identifiant court du client)
# Returns:
#   0 si trouvé ; 1 sinon
# Side effects:
#   - Affiche l'ID sur stdout
# Example:
#   id="$(clients_repo_find_id_by_slug "mon-client")"
clients_repo_find_id_by_slug() {
  local slug="${1:-}"
  [[ -n "$slug" ]] || return 1
  local f
  f="$(clients_index_file_by_slug "$slug")"
  [[ -f "$f" ]] || return 1
  cat "$f"
}

# clients_repo_save_new — Enregistre un nouveau client dans le dépôt
# Args:
#   $1: id (UUID)
#   $2: slug (identifiant court)
#   $3: json (objet JSON client complet)
# Returns:
#   0 si succès ; 1 si args manquants ; 2 si slug déjà utilisé
# Side effects:
#   - Crée les fichiers JSON et d'index
#   - Appelle log_error si slug dupliqué
# Example:
#   clients_repo_save_new "uuid-123" "mon-client" '{"id":"...","slug":"..."}'
clients_repo_save_new() {
  # args: id slug json
  local id="${1:-}" slug="${2:-}" json="${3:-}"
  [[ -n "$id" && -n "$slug" ]] || return 1

  clients_repo_init

  local by_slug
  by_slug="$(clients_index_file_by_slug "$slug")"
  if [[ -f "$by_slug" ]]; then
    log_error "Slug déjà utilisé: $slug"
    return 2
  fi

  atomic_write "$(clients_repo_file_by_id "$id")" "$json"
  atomic_write "$by_slug" "$id"
}

# clients_repo_update — Met à jour un client existant dans le dépôt
# Args:
#   $1: id (UUID du client)
#   $2: old_slug (ancien slug)
#   $3: new_slug (nouveau slug, peut être vide pour conserver)
#   $4: json (objet JSON client updated)
# Returns:
#   0 si succès ; 1 si args manquants ; 2 si nouveau slug dupliqué
# Side effects:
#   - Met à jour le fichier JSON et réorganise l'index si slug change
#   - Appelle log_error si slug dupliqué
# Example:
#   clients_repo_update "uuid" "ancien" "nouveau" '{"id":"...","slug":"nouveau"}'
clients_repo_update() {
  # args: id old_slug new_slug json
  local id="${1:-}" old_slug="${2:-}" new_slug="${3:-}" json="${4:-}"
  [[ -n "$id" && -n "$old_slug" ]] || return 1

  clients_repo_init

  # si slug change: vérifier collision
  if [[ -n "$new_slug" && "$new_slug" != "$old_slug" ]]; then
    local newf
    newf="$(clients_index_file_by_slug "$new_slug")"
    [[ ! -f "$newf" ]] || { log_error "Slug déjà utilisé: $new_slug"; return 2; }
  fi

  atomic_write "$(clients_repo_file_by_id "$id")" "$json"

  if [[ -n "$new_slug" && "$new_slug" != "$old_slug" ]]; then
    rm -f "$(clients_index_file_by_slug "$old_slug")"
    atomic_write "$(clients_index_file_by_slug "$new_slug")" "$id"
  fi
}

# clients_repo_delete — Supprime un client du dépôt
# Args:
#   $1: id (UUID du client)
#   $2: slug (identifiant court du client)
# Returns:
#   0 si succès ; 1 si args manquants
# Side effects:
#   - Supprime le fichier JSON et l'entrée d'index
# Example:
#   clients_repo_delete "uuid-123" "mon-client"
clients_repo_delete() {
  # args: id slug
  local id="${1:-}" slug="${2:-}"
  [[ -n "$id" && -n "$slug" ]] || return 1

  rm -f "$(clients_repo_file_by_id "$id")"
  rm -f "$(clients_index_file_by_slug "$slug")"
}

# clients_repo_list_lines — Énumère tous les clients du dépôt
# Args: none
# Returns:
#   0 toujours
# Side effects:
#   - Affiche les clients au format "ID<TAB>SLUG<TAB>NAME" (une ligne par client)
#   - Initialise le dépôt s'il n'existe pas
# Example:
#   clients_repo_list_lines | while IFS=$'\t' read id slug name; do echo "$slug"; done
clients_repo_list_lines() {
  # output: id<TAB>slug<TAB>name
  clients_repo_init

  local f id slug name
  for f in "$(clients_repo_dir)"/*.json; do
    [[ -f "$f" ]] || continue
    id="$(basename "$f" .json)"
    slug="$(jq -r '.slug // empty' "$f" 2>/dev/null || true)"
    name="$(jq -r '.name // empty' "$f" 2>/dev/null || true)"
    [[ -n "$id" ]] || continue
    printf '%s\t%s\t%s\n' "$id" "$slug" "$name"
  done
}


# clients_repo_read_by_id
# Summary: Alias pour récupérer le JSON d'un client par son ID.
# Args:
#   $1: id (UUID du client)
# Returns:
#   0 si trouvé ; 1 sinon
# Side effects:
#   - Affiche le JSON du client sur stdout
# Example: clients_repo_read_by_id "uuid-123"
clients_repo_read_by_id() {
  clients_repo_get_by_id "$@"
}

# clients_repo_list_ids
# Summary: Liste les IDs (noms de fichiers sans extension) de tous les clients.
# Args: none
# Returns:
#   0 toujours
# Side effects:
#   - Affiche chaque ID sur stdout, une par ligne
# Example: clients_repo_list_ids
clients_repo_list_ids() {
  clients_repo_init
  local f
  for f in "$(clients_repo_dir)"/*.json; do
    [[ -f "$f" ]] || continue
    basename "$f" .json
  done
}