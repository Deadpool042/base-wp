#!/usr/bin/env bash
set -euo pipefail

clients_domain_validate_slug() {
  local slug="${1:-}"
  require_nonempty "$slug" || return 1
  require_slug "$slug" || return 1
}

clients_domain_normalize_slug() {
  slug_normalize "${1:-}"
}

clients_domain_defaults_json() {
  # args: id slug name ts
  local id="$1" slug="$2" name="$3" ts="$4"
  jq -n \
    --arg id "$id" \
    --arg slug "$slug" \
    --arg name "$name" \
    --arg ts "$ts" \
    '{
      version: 1,
      id: $id,
      slug: $slug,
      name: $name,
      contact: { email: "", phone: "" },
      createdAt: $ts,
      updatedAt: $ts
    }'
}
