#!/usr/bin/env bash
set -euo pipefail

# clients_create — Crée un nouveau client
# Args:
#   --slug <slug>: identifiant court (requis, normalisé)
#   --name <name>: nom du client (optionnel, par défaut = slug)
#   --email <email>: email de contact (optionnel)
#   --phone <phone>: téléphone (optionnel)
# Returns:
#   0 si succès ; 1 si validation échoue ; 127 si jq manquant
# Side effects:
#   - Émet des événements NDJSON (error ou created+success)
#   - Crée les fichiers client et l'index slug
# Example:
#   clients_create --slug "mon-client" --name "Mon Client SARL" --email "info@example.com"
clients_create() {
  clients_repo_init
  require_jq || return 127

  local slug="" name="" email="" phone=""
  args_parse_kv "$@" \
    --slug slug \
    --name name \
    --email email \
    --phone phone

  slug="$(clients_domain_normalize_slug "$slug")"
  clients_domain_validate_slug "$slug" || { emit error code=VALIDATION message="invalid slug"; return 1; }
  require_nonempty "$name" || name="$slug"

  # slug unique
  if [[ -n "$(clients_index_get_id_by_slug "$slug" || true)" ]]; then
    emit error code=ALREADY_EXISTS message="slug already exists" slug="$slug"
    return 1
  fi

  local id ts json
  id="$(uuid_v4)"
  ts="$(now_utc)"

  json="$(clients_domain_defaults_json "$id" "$slug" "$name" "$ts")"
  json="$(printf '%s' "$json" | jq \
    --arg email "$email" \
    --arg phone "$phone" \
    --arg ts "$ts" \
    '.contact.email=$email
     | .contact.phone=$phone
     | .updatedAt=$ts
    ')"

  clients_repo_write_by_id "$id" "$json"
  clients_index_set_slug "$slug" "$id"

  emit created type=client id="$id" slug="$slug" name="$name"
}
