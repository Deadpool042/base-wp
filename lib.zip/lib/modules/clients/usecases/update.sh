#!/usr/bin/env bash
set -euo pipefail

# clients_update — Met à jour un client existant
# Args:
#   $1: ID (UUID) ou slug du client à modifier
#   --slug <slug>: nouveau slug (optionnel)
#   --name <name>: nouveau nom (optionnel)
#   --email <email>: nouvel email (optionnel)
#   --phone <phone>: nouveau téléphone (optionnel)
# Returns:
#   0 si succès ; 1 si client introuvable ou slug dupliqué ; 127 si jq manquant
# Side effects:
#   - Met à jour le fichier JSON et l'index slug si changement
#   - Émet un événement updated ou error
# Example:
#   clients_update "mon-client" --name "Nouveau nom" --email "new@example.com"
clients_update() {
  clients_repo_init
  require_jq || return 127

  local input="${1:-}"
  shift || true
  require_nonempty "$input" || { emit error code=VALIDATION message="id or slug required"; return 1; }

  local id
  id="$(clients_resolve_id "$input")" || { emit error code=NOT_FOUND message="client not found" input="$input"; return 1; }

  local slug="" name="" email="" phone=""
  args_parse_kv "$@" \
    --slug slug \
    --name name \
    --email email \
    --phone phone

  local json
  json="$(clients_repo_read_by_id "$id")"

  local old_slug
  old_slug="$(printf '%s' "$json" | jq -r '.slug // ""')"

  if [[ -n "$slug" ]]; then
    slug="$(clients_domain_normalize_slug "$slug")"
    clients_domain_validate_slug "$slug" || { emit error code=VALIDATION message="invalid slug"; return 1; }

    local existing
    existing="$(clients_index_get_id_by_slug "$slug" || true)"
    if [[ -n "$existing" && "$existing" != "$id" ]]; then
      emit error code=ALREADY_EXISTS message="slug already exists" slug="$slug"
      return 1
    fi
    json="$(printf '%s' "$json" | jq --arg slug "$slug" '.slug=$slug')"
  fi

  [[ -n "$name"  ]] && json="$(printf '%s' "$json" | jq --arg name "$name" '.name=$name')"
  [[ -n "$email" ]] && json="$(printf '%s' "$json" | jq --arg email "$email" '.contact.email=$email')"
  [[ -n "$phone" ]] && json="$(printf '%s' "$json" | jq --arg phone "$phone" '.contact.phone=$phone')"

  json="$(printf '%s' "$json" | jq --arg ts "$(now_utc)" '.updatedAt=$ts')"

  clients_repo_write_by_id "$id" "$json"

  local new_slug
  new_slug="$(printf '%s' "$json" | jq -r '.slug // ""')"
  if [[ -n "$new_slug" && "$new_slug" != "$old_slug" ]]; then
    clients_index_set_slug "$new_slug" "$id"
  else
    clients_index_set_slug "$old_slug" "$id"
  fi

  emit updated type=client id="$id"
}
