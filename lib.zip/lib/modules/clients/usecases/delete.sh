#!/usr/bin/env bash
set -euo pipefail

# clients_delete — Supprime un client (requiert --force)
# Args:
#   $1: ID (UUID) ou slug du client (optionnel si --select)
#   --force <0|1>: requis pour confirmer la suppression (défaut: 0)
#   --select <0|1>: si 1, sélectionne un client via menu interactif (défaut: 0)
# Returns:
#   0 si succès ; 1 si validation échoue ou force absent
# Side effects:
#   - Supprime les fichiers client et l'index slug
#   - Émet un événement deleted ou error/warn
# Example:
#   clients_delete "mon-client" --force 1
#   clients_delete --select 1 --force 1
clients_delete() {
  clients_repo_init

  local input="${1:-}"
  local force="0" select="0"
  shift || true

  args_parse_kv "$@" --force force --select select

  local id=""
  if [[ -n "$input" ]]; then
    id="$(clients_resolve_id "$input" || true)"
  fi

  if [[ -z "$id" && "${select:-0}" == "1" ]]; then
    id="$(clients_repo_list_select_lines | select_from_list "Select client to delete:" || true)"
  fi

  [[ -n "$id" ]] || { emit error code=VALIDATION message="id/slug required (or --select)"; return 1; }

  if [[ "${force:-0}" != "1" ]]; then
    emit warn message="Refusing delete without --force" id="$id"
    return 1
  fi

  clients_repo_delete_by_id "$id"
  clients_index_delete_id "$id"
  emit deleted type=client id="$id"
}
