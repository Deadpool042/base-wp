#!/usr/bin/env bash
set -euo pipefail

# clients_list — Liste tous les clients (format humain ou JSON)
# Args:
#   --json <0|1>: si 1, renvoie un JSON compact ; sinon format tabulaire (défaut: 0)
# Returns:
#   0 si succès ; 127 si jq manquant
# Side effects:
#   - Affiche la liste sur stdout
#   - Initialise le dépôt si nécessaire
# Example:
#   clients_list
#   clients_list --json 1
clients_list() {
  clients_repo_init
  require_jq || return 127

  local as_json="0"
  args_parse_kv "$@" --json as_json

  if [[ "${as_json:-0}" == "1" ]]; then
    jq -n --argjson items "$(clients_list_json_array)" '{items:$items}'
    return 0
  fi

  printf "%-36s  %-20s  %s\n" "ID" "SLUG" "NAME"
  while IFS= read -r id; do
    local j slug name
    j="$(clients_repo_read_by_id "$id" || true)"
    slug="$(printf '%s' "$j" | jq -r '.slug // ""' 2>/dev/null || true)"
    name="$(printf '%s' "$j" | jq -r '.name // ""' 2>/dev/null || true)"
    printf "%-36s  %-20s  %s\n" "$id" "$slug" "$name"
  done < <(clients_repo_list_ids)
}

# clients_list_json_array — Construit un tableau JSON de tous les clients
# Args: none
# Returns:
#   0 toujours
# Side effects:
#   - Affiche le tableau JSON sur stdout
#   - Lit tous les clients via clients_repo_read_by_id
# Example:
#   arr="$(clients_list_json_array)"
clients_list_json_array() {
  local arr="[]"
  while IFS= read -r id; do
    local j
    j="$(clients_repo_read_by_id "$id" || true)"
    arr="$(jq -n --argjson arr "$arr" --argjson item "$j" '$arr + [$item]')"
  done < <(clients_repo_list_ids)
  printf '%s' "$arr"
}
