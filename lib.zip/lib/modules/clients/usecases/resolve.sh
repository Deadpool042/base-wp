#!/usr/bin/env bash
set -euo pipefail

# clients_resolve_id — Résout un ID client depuis un UUID ou un slug
# Args:
#   $1: input (UUID ou slug du client)
# Returns:
#   0 si résolu ; 1 si introuvable ou validation échoue
# Side effects:
#   - Affiche l'ID (UUID) sur stdout
# Example:
#   id="$(clients_resolve_id "mon-client")"
#   id="$(clients_resolve_id "uuid-123")"
clients_resolve_id() {
  local input="${1:-}"
  require_nonempty "$input" || return 1

  if is_uuid "$input"; then
    echo "$input"
    return 0
  fi

  local slug
  slug="$(clients_domain_normalize_slug "$input")"
  clients_domain_validate_slug "$slug" || return 1

  local id
  id="$(clients_index_get_id_by_slug "$slug")"
  [[ -n "$id" ]] || return 1
  echo "$id"
}
