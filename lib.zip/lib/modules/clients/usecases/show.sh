#!/usr/bin/env bash
set -euo pipefail

# clients_show — Affiche les détails d'un client par ID ou slug
# Args:
#   $1: ID (UUID) ou slug du client
# Returns:
#   0 si trouvé ; 1 si introuvable ou arg manquant ; 127 si jq manquant
# Side effects:
#   - Affiche le JSON client sur stdout
#   - Émet un événement error si introuvable
# Example:
#   clients_show "mon-client"
#   clients_show "uuid-123"
clients_show() {
  clients_repo_init
  require_jq || return 127

  local input="${1:-}"
  require_nonempty "$input" || { emit error code=VALIDATION message="id or slug required"; return 1; }

  local id
  id="$(clients_resolve_id "$input")" || { emit error code=NOT_FOUND message="client not found" input="$input"; return 1; }

  clients_repo_read_by_id "$id" | jq '.'
}
