#!/usr/bin/env bash
set -euo pipefail

sf_require_source "domains/clients/model.sh"
sf_require_source "domains/clients/rules.sh"
sf_require_source "infra/storage/clients_repo_fs.sh"
# usecase_clients_create — Cas d'usage de création d'un nouveau client
# Args:
#   $1: slug (identifiant kebab-case du client)
#   $2: name (nom lisible du client)
# Returns:
#   0 si succès ; 1 si validation échoue ; 2 si slug existe déjà
# Side effects:
#   - Initialise le repo clients si nécessaire
#   - Sauvegarde le nouveau client dans le repo
#   - Affiche le JSON du client créé sur stdout
# Example:
#   json="$(usecase_clients_create "acme" "ACME Corp")"
usecase_clients_create() {
  local slug="$1" name="$2"
  clients_repo_init

  client_validate "$slug" "$name" || return 1
  clients_repo_slug_exists "$slug" && return 2

  local id ts
  id="$(uuidgen | tr 'A-Z' 'a-z')"
  ts="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"

  local json
  json="$(client_new "$id" "$slug" "$name" "$ts")"
  clients_repo_save "$id" "$slug" "$json"

  echo "$json"
}
